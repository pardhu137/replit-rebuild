import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, ReactNode } from 'react';
import type { Area, Village, Customer, FinanceEvent, DashboardData, CustomerLoanSummary, DateFilter } from './types';
import { AreaStorage, VillageStorage, CustomerStorage, EventStorage } from './storage';
import { calculateDashboard, getCustomerLoanSummary, filterEventsByDate } from './calculations';

interface AppContextValue {
  areas: Area[];
  selectedAreaId: string | null;
  selectedArea: Area | null;
  villages: Village[];
  customers: Customer[];
  events: FinanceEvent[];
  dashboard: DashboardData;
  customerSummaries: CustomerLoanSummary[];
  loading: boolean;
  dateFilter: DateFilter;
  setDateFilter: (filter: DateFilter) => void;
  selectArea: (areaId: string) => Promise<void>;
  createArea: (name: string, isOnboarding: boolean, openingBalance?: number) => Promise<Area>;
  deleteArea: (id: string) => Promise<void>;
  createVillage: (name: string) => Promise<Village>;
  deleteVillage: (id: string) => Promise<void>;
  createCustomer: (data: { villageId: string; villageName: string; name: string; phone: string }) => Promise<Customer>;
  deleteCustomer: (id: string) => Promise<void>;
  createNewLoan: (customerId: string, customerName: string, loanAmount: number, totalPayable: number, totalInstallments: number, paidInstallments?: number, paidAmount?: number) => Promise<void>;
  renewLoan: (customerId: string, customerName: string, previousLoanEventId: string, loanAmount: number, totalPayable: number, totalInstallments: number) => Promise<void>;
  makePayment: (customerId: string, customerName: string, loanEventId: string, onlineAmount: number, offlineAmount: number) => Promise<void>;
  addExpense: (amount: number, description: string) => Promise<void>;
  addCapital: (amount: number, description: string) => Promise<void>;
  createAdjustment: (referenceEventId: string, amount: number, reason: string) => Promise<void>;
  refreshData: () => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [areas, setAreas] = useState<Area[]>([]);
  const [selectedAreaId, setSelectedAreaId] = useState<string | null>(null);
  const [villages, setVillages] = useState<Village[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [events, setEvents] = useState<FinanceEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [dateFilter, setDateFilter] = useState<DateFilter>({ mode: 'all' });

  const selectedArea = useMemo(
    () => areas.find(a => a.id === selectedAreaId) ?? null,
    [areas, selectedAreaId]
  );

  const dashboard = useMemo(
    () => calculateDashboard(events, dateFilter),
    [events, dateFilter]
  );

  const customerSummaries = useMemo(() => {
    return customers
      .map(c => getCustomerLoanSummary(c, events))
      .sort((a, b) => {
        if (a.isFullyPaid && !b.isFullyPaid) return 1;
        if (!a.isFullyPaid && b.isFullyPaid) return -1;
        if (a.paidToday && !b.paidToday) return 1;
        if (!a.paidToday && b.paidToday) return -1;
        return a.customer.serialNumber - b.customer.serialNumber;
      });
  }, [customers, events]);

  const loadData = useCallback(async (areaId?: string | null) => {
    const aid = areaId ?? selectedAreaId;
    if (!aid) return;

    const [v, c, e] = await Promise.all([
      VillageStorage.getByArea(aid),
      CustomerStorage.getByArea(aid),
      EventStorage.getByArea(aid),
    ]);
    setVillages(v);
    setCustomers(c);
    setEvents(e);
  }, [selectedAreaId]);

  const refreshData = useCallback(async () => {
    const allAreas = await AreaStorage.getAll();
    setAreas(allAreas);
    if (selectedAreaId) {
      await loadData(selectedAreaId);
    }
  }, [selectedAreaId, loadData]);

  useEffect(() => {
    (async () => {
      try {
        const allAreas = await AreaStorage.getAll();
        setAreas(allAreas);
        const savedArea = await AreaStorage.getSelected();
        if (savedArea && allAreas.some(a => a.id === savedArea)) {
          setSelectedAreaId(savedArea);
        } else if (allAreas.length > 0) {
          setSelectedAreaId(allAreas[0].id);
          await AreaStorage.setSelected(allAreas[0].id);
        }
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  useEffect(() => {
    if (selectedAreaId) {
      loadData(selectedAreaId);
    }
  }, [selectedAreaId, loadData]);

  const selectArea = useCallback(async (areaId: string) => {
    setSelectedAreaId(areaId);
    await AreaStorage.setSelected(areaId);
  }, []);

  const createArea = useCallback(async (name: string, isOnboarding: boolean, openingBalance?: number) => {
    const area = await AreaStorage.create(name, isOnboarding);
    if (isOnboarding && openingBalance && openingBalance > 0) {
      await EventStorage.create(area.id, 'ONBOARDING_BALANCE', { amount: openingBalance });
    }
    const allAreas = await AreaStorage.getAll();
    setAreas(allAreas);
    if (!selectedAreaId) {
      setSelectedAreaId(area.id);
      await AreaStorage.setSelected(area.id);
    }
    return area;
  }, [selectedAreaId]);

  const deleteArea = useCallback(async (id: string) => {
    await AreaStorage.delete(id);
    const allAreas = await AreaStorage.getAll();
    setAreas(allAreas);
    if (selectedAreaId === id) {
      const newSelected = allAreas[0]?.id ?? null;
      setSelectedAreaId(newSelected);
      if (newSelected) await AreaStorage.setSelected(newSelected);
    }
  }, [selectedAreaId]);

  const createVillage = useCallback(async (name: string) => {
    if (!selectedAreaId) throw new Error('No area selected');
    const village = await VillageStorage.create(selectedAreaId, name);
    await loadData();
    return village;
  }, [selectedAreaId, loadData]);

  const deleteVillage = useCallback(async (id: string) => {
    await VillageStorage.delete(id);
    await loadData();
  }, [loadData]);

  const createCustomer = useCallback(async (data: { villageId: string; villageName: string; name: string; phone: string }) => {
    if (!selectedAreaId) throw new Error('No area selected');
    const serialNumber = await VillageStorage.incrementSerial(data.villageId);
    const customer = await CustomerStorage.create({
      areaId: selectedAreaId,
      villageId: data.villageId,
      villageName: data.villageName,
      name: data.name,
      phone: data.phone,
      serialNumber,
    });
    await loadData();
    return customer;
  }, [selectedAreaId, loadData]);

  const deleteCustomer = useCallback(async (id: string) => {
    await CustomerStorage.delete(id);
    await loadData();
  }, [loadData]);

  const createNewLoan = useCallback(async (
    customerId: string,
    customerName: string,
    loanAmount: number,
    totalPayable: number,
    totalInstallments: number,
    paidInstallments?: number,
    paidAmount?: number
  ) => {
    if (!selectedAreaId) throw new Error('No area selected');
    const loanEvent = await EventStorage.create(selectedAreaId, 'NEW_LOAN', {
      customerId,
      customerName,
      loanAmount,
      totalPayable,
      totalInstallments,
    });

    if (paidInstallments && paidAmount && paidAmount > 0) {
      const perInstallment = paidAmount / paidInstallments;
      for (let i = 0; i < paidInstallments; i++) {
        await EventStorage.create(selectedAreaId, 'INSTALLMENT_PAYMENT', {
          customerId,
          customerName,
          loanEventId: loanEvent.eventId,
          onlineAmount: 0,
          offlineAmount: perInstallment,
          totalAmount: perInstallment,
          isOnboarding: true,
        });
      }
    }

    await loadData();
  }, [selectedAreaId, loadData]);

  const renewLoan = useCallback(async (
    customerId: string,
    customerName: string,
    previousLoanEventId: string,
    loanAmount: number,
    totalPayable: number,
    totalInstallments: number
  ) => {
    if (!selectedAreaId) throw new Error('No area selected');
    await EventStorage.create(selectedAreaId, 'RENEW_LOAN', {
      customerId,
      customerName,
      loanAmount,
      totalPayable,
      totalInstallments,
      previousLoanEventId,
    });
    await loadData();
  }, [selectedAreaId, loadData]);

  const makePayment = useCallback(async (
    customerId: string,
    customerName: string,
    loanEventId: string,
    onlineAmount: number,
    offlineAmount: number
  ) => {
    if (!selectedAreaId) throw new Error('No area selected');
    await EventStorage.create(selectedAreaId, 'INSTALLMENT_PAYMENT', {
      customerId,
      customerName,
      loanEventId,
      onlineAmount,
      offlineAmount,
      totalAmount: onlineAmount + offlineAmount,
    });
    await loadData();
  }, [selectedAreaId, loadData]);

  const addExpense = useCallback(async (amount: number, description: string) => {
    if (!selectedAreaId) throw new Error('No area selected');
    await EventStorage.create(selectedAreaId, 'EXPENSE', { amount, description });
    await loadData();
  }, [selectedAreaId, loadData]);

  const addCapital = useCallback(async (amount: number, description: string) => {
    if (!selectedAreaId) throw new Error('No area selected');
    await EventStorage.create(selectedAreaId, 'CAPITAL_ADDED', { amount, description });
    await loadData();
  }, [selectedAreaId, loadData]);

  const createAdjustment = useCallback(async (referenceEventId: string, amount: number, reason: string) => {
    if (!selectedAreaId) throw new Error('No area selected');
    await EventStorage.create(selectedAreaId, 'ADJUSTMENT_EVENT', {
      referenceEventId,
      amount,
      reason,
    });
    await loadData();
  }, [selectedAreaId, loadData]);

  const value = useMemo(() => ({
    areas,
    selectedAreaId,
    selectedArea,
    villages,
    customers,
    events,
    dashboard,
    customerSummaries,
    loading,
    dateFilter,
    setDateFilter,
    selectArea,
    createArea,
    deleteArea,
    createVillage,
    deleteVillage,
    createCustomer,
    deleteCustomer,
    createNewLoan,
    renewLoan,
    makePayment,
    addExpense,
    addCapital,
    createAdjustment,
    refreshData,
  }), [
    areas, selectedAreaId, selectedArea, villages, customers, events,
    dashboard, customerSummaries, loading, dateFilter, selectArea, createArea,
    deleteArea, createVillage, deleteVillage, createCustomer, deleteCustomer,
    createNewLoan, renewLoan, makePayment, addExpense, addCapital,
    createAdjustment, refreshData,
  ]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
}
