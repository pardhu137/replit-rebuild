import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Crypto from 'expo-crypto';
import type { Area, Village, Customer, FinanceEvent } from './types';

const KEYS = {
  AREAS: 'finance_areas',
  VILLAGES: 'finance_villages',
  CUSTOMERS: 'finance_customers',
  EVENTS: 'finance_events',
  SELECTED_AREA: 'finance_selected_area',
  DEVICE_ID: 'finance_device_id',
};

export function generateId(): string {
  return Crypto.randomUUID();
}

async function getDeviceId(): Promise<string> {
  let deviceId = await AsyncStorage.getItem(KEYS.DEVICE_ID);
  if (!deviceId) {
    deviceId = generateId();
    await AsyncStorage.setItem(KEYS.DEVICE_ID, deviceId);
  }
  return deviceId;
}

async function getItems<T>(key: string): Promise<T[]> {
  const data = await AsyncStorage.getItem(key);
  return data ? JSON.parse(data) : [];
}

async function setItems<T>(key: string, items: T[]): Promise<void> {
  await AsyncStorage.setItem(key, JSON.stringify(items));
}

export const AreaStorage = {
  async getAll(): Promise<Area[]> {
    return getItems<Area>(KEYS.AREAS);
  },

  async create(name: string, isOnboarding: boolean): Promise<Area> {
    const areas = await this.getAll();
    const area: Area = {
      id: generateId(),
      name,
      createdAt: new Date().toISOString(),
      isOnboarding,
    };
    areas.push(area);
    await setItems(KEYS.AREAS, areas);
    return area;
  },

  async delete(id: string): Promise<void> {
    const areas = await this.getAll();
    await setItems(KEYS.AREAS, areas.filter(a => a.id !== id));
    const villages = await VillageStorage.getByArea(id);
    for (const v of villages) {
      await VillageStorage.delete(v.id);
    }
    const customers = await CustomerStorage.getByArea(id);
    for (const c of customers) {
      await CustomerStorage.delete(c.id);
    }
  },

  async getSelected(): Promise<string | null> {
    return AsyncStorage.getItem(KEYS.SELECTED_AREA);
  },

  async setSelected(areaId: string): Promise<void> {
    await AsyncStorage.setItem(KEYS.SELECTED_AREA, areaId);
  },
};

export const VillageStorage = {
  async getAll(): Promise<Village[]> {
    return getItems<Village>(KEYS.VILLAGES);
  },

  async getByArea(areaId: string): Promise<Village[]> {
    const all = await this.getAll();
    return all.filter(v => v.areaId === areaId);
  },

  async create(areaId: string, name: string): Promise<Village> {
    const all = await this.getAll();
    const village: Village = {
      id: generateId(),
      areaId,
      name,
      nextSerialNumber: 1,
      createdAt: new Date().toISOString(),
    };
    all.push(village);
    await setItems(KEYS.VILLAGES, all);
    return village;
  },

  async incrementSerial(villageId: string): Promise<number> {
    const all = await this.getAll();
    const village = all.find(v => v.id === villageId);
    if (!village) throw new Error('Village not found');
    const serial = village.nextSerialNumber;
    village.nextSerialNumber += 1;
    await setItems(KEYS.VILLAGES, all);
    return serial;
  },

  async delete(id: string): Promise<void> {
    const all = await this.getAll();
    await setItems(KEYS.VILLAGES, all.filter(v => v.id !== id));
  },
};

export const CustomerStorage = {
  async getAll(): Promise<Customer[]> {
    return getItems<Customer>(KEYS.CUSTOMERS);
  },

  async getByArea(areaId: string): Promise<Customer[]> {
    const all = await this.getAll();
    return all.filter(c => c.areaId === areaId);
  },

  async getById(id: string): Promise<Customer | undefined> {
    const all = await this.getAll();
    return all.find(c => c.id === id);
  },

  async create(data: Omit<Customer, 'id' | 'createdAt'>): Promise<Customer> {
    const all = await this.getAll();
    const customer: Customer = {
      ...data,
      id: generateId(),
      createdAt: new Date().toISOString(),
    };
    all.push(customer);
    await setItems(KEYS.CUSTOMERS, all);
    return customer;
  },

  async delete(id: string): Promise<void> {
    const all = await this.getAll();
    await setItems(KEYS.CUSTOMERS, all.filter(c => c.id !== id));
  },
};

export const EventStorage = {
  async getAll(): Promise<FinanceEvent[]> {
    return getItems<FinanceEvent>(KEYS.EVENTS);
  },

  async getByArea(areaId: string): Promise<FinanceEvent[]> {
    const all = await this.getAll();
    return all.filter(e => e.areaId === areaId).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  },

  async create(
    areaId: string,
    eventType: FinanceEvent['eventType'],
    payload: FinanceEvent['payload']
  ): Promise<FinanceEvent> {
    const all = await this.getAll();
    const deviceId = await getDeviceId();
    const event: FinanceEvent = {
      eventId: generateId(),
      schemaVersion: 1,
      accountId: 'default',
      areaId,
      createdBy: 'owner',
      deviceId,
      createdAt: new Date().toISOString(),
      syncedAt: null,
      eventType,
      payload,
    };
    all.push(event);
    await setItems(KEYS.EVENTS, all);
    return event;
  },

  async getByCustomer(customerId: string): Promise<FinanceEvent[]> {
    const all = await this.getAll();
    return all.filter(e => {
      const p = e.payload as Record<string, unknown>;
      return p.customerId === customerId;
    }).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  },
};
