# CashBook - Offline-First Finance Ledger App

## Overview

CashBook is a mobile-first, offline-first, multi-tenant finance ledger application built with Expo (React Native) and an Express backend. It's designed for real cash collection and loan management operations, organized by geographic "Areas." The app follows an event-sourcing architecture where all financial actions (loans, payments, expenses, capital additions, adjustments) are recorded as immutable events, and all dashboard/summary views are derived from those events.

The app manages:
- **Areas** - Geographic regions that isolate all financial data
- **Villages** - Sub-divisions within areas
- **Customers** - Borrowers within villages
- **Loans** - New loans and renewals with installment tracking
- **Payments** - Online and offline installment collections
- **Expenses & Capital** - Operational costs and capital injections
- **Adjustments** - Corrections to previous events (never deletions)

Data is stored locally using AsyncStorage (offline-first) with a PostgreSQL backend for sync capability.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend (Expo / React Native)

- **Framework**: Expo SDK 54 with React Native 0.81, using expo-router for file-based routing
- **Navigation**: File-based routing via expo-router with Stack navigator. Area detail screen (`area/[id]`) contains tabs (Dashboard, Customers, History) to enforce area-scoped isolation
- **State Management**: React Context (`lib/context.tsx`) provides all app state and actions. No Redux or Zustand — single `AppProvider` wraps the entire app
- **Data Storage**: AsyncStorage for all local persistence (areas, villages, customers, events). Each entity type has its own storage helper in `lib/storage.ts`
- **Fonts**: Inter font family (400, 500, 600, 700 weights) via `@expo-google-fonts/inter`
- **UI Libraries**: react-native-gesture-handler, react-native-reanimated, react-native-keyboard-controller, expo-haptics for tactile feedback
- **Query Client**: TanStack React Query is set up (`lib/query-client.ts`) for API communication, though current data flow is primarily local

### Event-Sourcing Architecture

- **Core principle**: Every financial action creates an immutable event. Events are append-only — nothing is overwritten or deleted
- **Event types**: `ONBOARDING_BALANCE`, `NEW_LOAN`, `RENEW_LOAN`, `INSTALLMENT_PAYMENT`, `EXPENSE`, `CAPITAL_ADDED`, `ADJUSTMENT_EVENT`
- **Each event contains**: eventId, schemaVersion, accountId, areaId, createdBy, deviceId, createdAt, syncedAt, eventType, payload
- **Calculations**: Dashboard data and customer summaries are derived/computed from events in `lib/calculations.ts` — they are never stored directly
- **ID generation**: Uses `expo-crypto` (UUID) for all entity and event IDs

### Backend (Express)

- **Runtime**: Express 5 with TypeScript, compiled via esbuild for production
- **Database**: PostgreSQL via Drizzle ORM. Schema defined in `shared/schema.ts` (currently minimal — just a users table)
- **Storage layer**: `server/storage.ts` provides an in-memory storage implementation (MemStorage) with an IStorage interface ready for database migration
- **Routes**: `server/routes.ts` — currently minimal, ready for API endpoints prefixed with `/api`
- **CORS**: Configured for Replit domains and localhost development
- **Static serving**: Production mode serves built Expo web assets

### Key Design Decisions

1. **Area isolation**: All data is scoped to areas. The UI enforces that users must "enter" an area to see its dashboard, customers, and history. No cross-area data mixing
2. **Offline-first**: AsyncStorage is the primary data store. Server sync is secondary and designed to be idempotent
3. **Event immutability**: Corrections use ADJUSTMENT_EVENT rather than modifying/deleting existing events
4. **Shared types**: `lib/types.ts` defines all TypeScript interfaces for events, payloads, and domain entities used across the app

### Route Structure

```
/ (index)           → Areas list
/area/[id]          → Area home with tabs (Dashboard, Customers, History)
/area/create        → Modal: Create new area
/village/create     → Modal: Create village within area
/customer/create    → Modal: Create customer with initial loan
/customer/[id]      → Customer detail with loan history
/payment/[customerId] → Modal: Record payment
/loan/renew         → Modal: Renew loan for customer
/expense/create     → Modal: Record expense
/capital/create     → Modal: Add capital
/adjustment/create  → Modal: Create adjustment event
```

## External Dependencies

- **PostgreSQL**: Database for server-side storage and sync (configured via `DATABASE_URL` env var). Uses Drizzle ORM with `drizzle-kit` for migrations
- **AsyncStorage**: `@react-native-async-storage/async-storage` for local offline data persistence
- **Expo Services**: Expo SDK for build tooling, OTA updates, and native module access
- **TanStack React Query**: HTTP request caching and server state management (infrastructure ready, not heavily used yet)
- **Drizzle ORM + Zod**: Database schema definition and validation via `drizzle-zod`
- **No external auth service**: Currently using a basic user model; no OAuth or third-party auth integrated