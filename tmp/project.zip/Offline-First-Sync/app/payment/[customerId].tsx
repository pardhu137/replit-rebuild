import React, { useState, useMemo } from 'react';
import {
  StyleSheet, Text, View, TextInput, Pressable, Platform, KeyboardAvoidingView, ScrollView, Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { useApp } from '@/lib/context';
import { formatCurrency, getCustomerLoanSummary } from '@/lib/calculations';

export default function PaymentScreen() {
  const { customerId } = useLocalSearchParams<{ customerId: string }>();
  const insets = useSafeAreaInsets();
  const { customers, events, makePayment } = useApp();
  const [onlineAmount, setOnlineAmount] = useState('');
  const [offlineAmount, setOfflineAmount] = useState('');
  const [saving, setSaving] = useState(false);
  const topInset = Platform.OS === 'web' ? 67 : insets.top;

  const customer = customers.find(c => c.id === customerId);
  const summary = useMemo(() => {
    if (!customer) return null;
    return getCustomerLoanSummary(customer, events);
  }, [customer, events]);

  const totalAmount = (parseFloat(onlineAmount) || 0) + (parseFloat(offlineAmount) || 0);
  const canSave = totalAmount > 0 && summary?.activeLoanEventId;

  const handleSave = async () => {
    if (!canSave || saving || !customer || !summary?.activeLoanEventId) return;

    if (totalAmount > summary.remainingAmount) {
      Alert.alert('Warning', `Payment of ${formatCurrency(totalAmount)} exceeds remaining ${formatCurrency(summary.remainingAmount)}. Continue?`, [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Continue', onPress: doSave },
      ]);
      return;
    }

    doSave();
  };

  const doSave = async () => {
    if (!customer || !summary?.activeLoanEventId) return;
    setSaving(true);
    try {
      await makePayment(
        customer.id,
        customer.name,
        summary.activeLoanEventId,
        parseFloat(onlineAmount) || 0,
        parseFloat(offlineAmount) || 0,
      );
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.back();
    } catch {
      setSaving(false);
    }
  };

  if (!customer || !summary) {
    return (
      <View style={[s.container, { paddingTop: topInset }]}>
        <View style={s.header}>
          <Pressable onPress={() => router.back()}>
            <Feather name="x" size={22} color={Colors.text} />
          </Pressable>
          <Text style={s.headerTitle}>Payment</Text>
          <View style={{ width: 40 }} />
        </View>
        <View style={s.empty}><Text>Customer not found</Text></View>
      </View>
    );
  }

  return (
    <View style={[s.container, { paddingTop: topInset }]}>
      <View style={s.header}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [s.closeBtn, pressed && { opacity: 0.5 }]}>
          <Feather name="x" size={22} color={Colors.text} />
        </Pressable>
        <Text style={s.headerTitle}>Record Payment</Text>
        <Pressable
          onPress={handleSave}
          disabled={!canSave || saving}
          style={({ pressed }) => [s.saveBtn, pressed && { opacity: 0.7 }, (!canSave || saving) && { opacity: 0.4 }]}
        >
          <Feather name="check" size={22} color={Colors.primary} />
        </Pressable>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView contentContainerStyle={s.form} keyboardShouldPersistTaps="handled">
          <View style={s.customerBadge}>
            <View style={s.serialSmall}>
              <Text style={s.serialSmallText}>#{customer.serialNumber}</Text>
            </View>
            <View>
              <Text style={s.customerName}>{customer.name}</Text>
              <Text style={s.customerVillage}>{customer.villageName}</Text>
            </View>
          </View>

          <View style={s.remainingCard}>
            <Text style={s.remainingLabel}>Remaining</Text>
            <Text style={s.remainingValue}>{formatCurrency(summary.remainingAmount)}</Text>
            <Text style={s.remainingSub}>
              {summary.remainingInstallments} installments left
            </Text>
          </View>

          <Text style={s.label}>Cash Amount</Text>
          <TextInput
            style={s.input}
            placeholder="0"
            placeholderTextColor={Colors.textMuted}
            value={offlineAmount}
            onChangeText={setOfflineAmount}
            keyboardType="numeric"
            autoFocus
          />

          <Text style={s.label}>Online Amount</Text>
          <TextInput
            style={s.input}
            placeholder="0"
            placeholderTextColor={Colors.textMuted}
            value={onlineAmount}
            onChangeText={setOnlineAmount}
            keyboardType="numeric"
          />

          {totalAmount > 0 && (
            <View style={s.totalCard}>
              <Text style={s.totalLabel}>Total Payment</Text>
              <Text style={s.totalValue}>{formatCurrency(totalAmount)}</Text>
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  closeBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 17, color: Colors.text },
  saveBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  form: { padding: 20 },
  customerBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: Colors.white, borderRadius: 12, padding: 14,
    marginBottom: 16,
  },
  serialSmall: {
    width: 40, height: 40, borderRadius: 10, backgroundColor: Colors.primaryLight,
    alignItems: 'center', justifyContent: 'center',
  },
  serialSmallText: { fontFamily: 'Inter_700Bold', fontSize: 14, color: Colors.primary },
  customerName: { fontFamily: 'Inter_600SemiBold', fontSize: 16, color: Colors.text },
  customerVillage: { fontFamily: 'Inter_400Regular', fontSize: 13, color: Colors.textSecondary },
  remainingCard: {
    backgroundColor: Colors.warningLight, borderRadius: 12, padding: 16,
    alignItems: 'center', marginBottom: 24,
  },
  remainingLabel: { fontFamily: 'Inter_500Medium', fontSize: 12, color: Colors.warning },
  remainingValue: { fontFamily: 'Inter_700Bold', fontSize: 28, color: Colors.warning, marginTop: 4 },
  remainingSub: { fontFamily: 'Inter_400Regular', fontSize: 12, color: Colors.warning, marginTop: 4 },
  label: { fontFamily: 'Inter_600SemiBold', fontSize: 14, color: Colors.text, marginBottom: 8, marginTop: 16 },
  input: {
    backgroundColor: Colors.white, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 14,
    fontFamily: 'Inter_400Regular', fontSize: 20, color: Colors.text,
    borderWidth: 1, borderColor: Colors.border, textAlign: 'center',
  },
  totalCard: {
    backgroundColor: Colors.successLight, borderRadius: 12, padding: 16,
    alignItems: 'center', marginTop: 24,
  },
  totalLabel: { fontFamily: 'Inter_500Medium', fontSize: 12, color: Colors.success },
  totalValue: { fontFamily: 'Inter_700Bold', fontSize: 24, color: Colors.success, marginTop: 4 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center' },
});
