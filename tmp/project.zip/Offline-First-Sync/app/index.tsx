import React from 'react';
import {
  StyleSheet, Text, View, Pressable, FlatList, Platform,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Feather, MaterialIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { useApp } from '@/lib/context';
import { formatDate } from '@/lib/calculations';

function AreaCard({ area }: { area: { id: string; name: string; createdAt: string } }) {
  return (
    <Pressable
      style={({ pressed }) => [s.areaCard, pressed && { opacity: 0.7, transform: [{ scale: 0.98 }] }]}
      onPress={() => {
        router.push({ pathname: '/area/[id]', params: { id: area.id } });
        Haptics.selectionAsync();
      }}
    >
      <View style={s.areaIcon}>
        <MaterialIcons name="location-on" size={22} color={Colors.primary} />
      </View>
      <View style={s.areaInfo}>
        <Text style={s.areaName}>{area.name}</Text>
        <Text style={s.areaSince}>Since {formatDate(area.createdAt)}</Text>
      </View>
      <Feather name="chevron-right" size={20} color={Colors.textMuted} />
    </Pressable>
  );
}

export default function AreasListScreen() {
  const insets = useSafeAreaInsets();
  const { areas, loading } = useApp();
  const topInset = Platform.OS === 'web' ? 67 : insets.top;

  return (
    <View style={[s.container, { paddingTop: topInset }]}>
      <View style={s.header}>
        <View style={{ flex: 1 }}>
          <Text style={s.accountLabel}>CASHBOOK</Text>
          <Text style={s.title}>Your Areas</Text>
        </View>
      </View>

      <FlatList
        data={areas}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <AreaCard area={item} />}
        contentContainerStyle={s.list}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          !loading ? (
            <View style={s.empty}>
              <View style={s.emptyIcon}>
                <MaterialIcons name="account-balance" size={48} color={Colors.primary} />
              </View>
              <Text style={s.emptyTitle}>No areas yet</Text>
              <Text style={s.emptyText}>
                Create your first finance area to start tracking collections and loans
              </Text>
            </View>
          ) : null
        }
        ListFooterComponent={
          <Pressable
            style={({ pressed }) => [s.newAreaBtn, pressed && { opacity: 0.8, transform: [{ scale: 0.97 }] }]}
            onPress={() => {
              router.push('/area/create');
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            }}
          >
            <Feather name="plus" size={18} color={Colors.white} />
            <Text style={s.newAreaBtnText}>New Area</Text>
          </Pressable>
        }
        ListFooterComponentStyle={s.footer}
      />
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingTop: 20, paddingBottom: 8,
  },
  accountLabel: {
    fontFamily: 'Inter_600SemiBold', fontSize: 12, color: Colors.primary,
    letterSpacing: 1.5, marginBottom: 4,
  },
  title: { fontFamily: 'Inter_700Bold', fontSize: 26, color: Colors.text },
  list: { paddingHorizontal: 20, paddingTop: 16 },
  areaCard: {
    flexDirection: 'row', alignItems: 'center', gap: 14,
    backgroundColor: Colors.white, borderRadius: 14, padding: 16, marginBottom: 10,
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4,
    elevation: 2,
  },
  areaIcon: {
    width: 44, height: 44, borderRadius: 12, backgroundColor: Colors.primaryLight,
    alignItems: 'center', justifyContent: 'center',
  },
  areaInfo: { flex: 1 },
  areaName: { fontFamily: 'Inter_600SemiBold', fontSize: 17, color: Colors.text },
  areaSince: { fontFamily: 'Inter_400Regular', fontSize: 13, color: Colors.textSecondary, marginTop: 2 },
  footer: { alignItems: 'center', paddingTop: 20, paddingBottom: 40 },
  newAreaBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: Colors.primary, paddingHorizontal: 28, paddingVertical: 14,
    borderRadius: 28,
  },
  newAreaBtnText: { fontFamily: 'Inter_600SemiBold', fontSize: 15, color: Colors.white },
  empty: { alignItems: 'center', paddingTop: 60, gap: 12 },
  emptyIcon: {
    width: 80, height: 80, borderRadius: 20, backgroundColor: Colors.primaryLight,
    alignItems: 'center', justifyContent: 'center', marginBottom: 8,
  },
  emptyTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 18, color: Colors.text },
  emptyText: {
    fontFamily: 'Inter_400Regular', fontSize: 14, color: Colors.textSecondary,
    textAlign: 'center', lineHeight: 20, paddingHorizontal: 20,
  },
});
