import React, { useState } from 'react';
import {
  StyleSheet, Text, View, TextInput, Pressable, Platform, KeyboardAvoidingView, ScrollView, Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { useApp } from '@/lib/context';

export default function CreateCapitalScreen() {
  const insets = useSafeAreaInsets();
  const { addCapital, selectedArea } = useApp();
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [saving, setSaving] = useState(false);
  const topInset = Platform.OS === 'web' ? 67 : insets.top;

  const canSave = amount && description.trim();

  const handleSave = async () => {
    if (!canSave || saving) return;
    const a = parseFloat(amount);
    if (isNaN(a) || a <= 0) {
      Alert.alert('Invalid Amount', 'Please enter a valid amount');
      return;
    }
    setSaving(true);
    try {
      await addCapital(a, description.trim());
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.back();
    } catch {
      setSaving(false);
    }
  };

  return (
    <View style={[s.container, { paddingTop: topInset }]}>
      <View style={s.header}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [s.closeBtn, pressed && { opacity: 0.5 }]}>
          <Feather name="x" size={22} color={Colors.text} />
        </Pressable>
        <Text style={s.headerTitle}>Add Capital</Text>
        <Pressable
          onPress={handleSave}
          disabled={!canSave || saving}
          style={({ pressed }) => [s.saveBtn, pressed && { opacity: 0.7 }, (!canSave || saving) && { opacity: 0.4 }]}
        >
          <Feather name="check" size={22} color={Colors.primary} />
        </Pressable>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView contentContainerStyle={s.form} keyboardShouldPersistTaps="handled">
          {selectedArea && (
            <View style={s.areaBadge}>
              <Feather name="map-pin" size={14} color={Colors.info} />
              <Text style={s.areaBadgeText}>{selectedArea.name}</Text>
            </View>
          )}

          <Text style={s.label}>Amount</Text>
          <TextInput
            style={s.input}
            placeholder="Enter capital amount"
            placeholderTextColor={Colors.textMuted}
            value={amount}
            onChangeText={setAmount}
            keyboardType="numeric"
            autoFocus
          />

          <Text style={s.label}>Description</Text>
          <TextInput
            style={[s.input, { height: 80, textAlignVertical: 'top' }]}
            placeholder="Source of capital"
            placeholderTextColor={Colors.textMuted}
            value={description}
            onChangeText={setDescription}
            multiline
          />
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  closeBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 17, color: Colors.text },
  saveBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  form: { padding: 20 },
  areaBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: Colors.infoLight,
    paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, alignSelf: 'flex-start',
  },
  areaBadgeText: { fontFamily: 'Inter_500Medium', fontSize: 13, color: Colors.info },
  label: { fontFamily: 'Inter_600SemiBold', fontSize: 14, color: Colors.text, marginBottom: 8, marginTop: 20 },
  input: {
    backgroundColor: Colors.white, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 14,
    fontFamily: 'Inter_400Regular', fontSize: 16, color: Colors.text,
    borderWidth: 1, borderColor: Colors.border,
  },
});
