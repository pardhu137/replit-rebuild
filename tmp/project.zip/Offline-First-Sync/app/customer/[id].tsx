import React, { useMemo } from 'react';
import {
  StyleSheet, Text, View, ScrollView, Pressable, Platform, Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { useApp } from '@/lib/context';
import { formatCurrency, getCustomerLoanSummary, formatDateTime, getEventLabel, getEventColor } from '@/lib/calculations';
import type { InstallmentPaymentPayload } from '@/lib/types';

export default function CustomerDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const { customers, events, deleteCustomer } = useApp();
  const topInset = Platform.OS === 'web' ? 67 : insets.top;

  const customer = customers.find(c => c.id === id);
  const summary = useMemo(() => {
    if (!customer) return null;
    return getCustomerLoanSummary(customer, events);
  }, [customer, events]);

  const customerEvents = useMemo(() => {
    return events.filter(e => {
      const p = e.payload as Record<string, unknown>;
      return p.customerId === id;
    }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [events, id]);

  if (!customer || !summary) {
    return (
      <View style={[s.container, { paddingTop: topInset }]}>
        <View style={s.header}>
          <Pressable onPress={() => router.back()}>
            <Feather name="arrow-left" size={22} color={Colors.text} />
          </Pressable>
          <Text style={s.headerTitle}>Customer</Text>
          <View style={{ width: 40 }} />
        </View>
        <View style={s.empty}>
          <Text style={s.emptyText}>Customer not found</Text>
        </View>
      </View>
    );
  }

  const confirmDelete = () => {
    Alert.alert(
      'Delete Customer',
      `Are you sure you want to delete "${customer.name}"? This cannot be undone.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            deleteCustomer(customer.id);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
            router.back();
          },
        },
      ]
    );
  };

  const perInstallment = summary.totalInstallments > 0
    ? summary.totalPayable / summary.totalInstallments
    : 0;

  return (
    <View style={[s.container, { paddingTop: topInset }]}>
      <View style={s.header}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [pressed && { opacity: 0.5 }]}>
          <Feather name="arrow-left" size={22} color={Colors.text} />
        </Pressable>
        <Text style={s.headerTitle}>{customer.name}</Text>
        <Pressable onPress={confirmDelete} style={({ pressed }) => [pressed && { opacity: 0.5 }]}>
          <Feather name="trash-2" size={20} color={Colors.danger} />
        </Pressable>
      </View>

      <ScrollView
        contentContainerStyle={{ paddingBottom: Platform.OS === 'web' ? 34 : insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={s.profileCard}>
          <View style={s.profileTop}>
            <View style={s.serialLarge}>
              <Text style={s.serialLargeText}>#{customer.serialNumber}</Text>
            </View>
            <View style={s.profileInfo}>
              <Text style={s.profileName}>{customer.name}</Text>
              <Text style={s.profileVillage}>{customer.villageName}</Text>
              {customer.phone ? <Text style={s.profilePhone}>{customer.phone}</Text> : null}
            </View>
          </View>

          {summary.hasLoan && (
            <View style={s.loanGrid}>
              <View style={s.loanCell}>
                <Text style={s.loanCellLabel}>Given</Text>
                <Text style={s.loanCellValue}>{formatCurrency(summary.loanAmount)}</Text>
              </View>
              <View style={s.loanCell}>
                <Text style={s.loanCellLabel}>Payable</Text>
                <Text style={s.loanCellValue}>{formatCurrency(summary.totalPayable)}</Text>
              </View>
              <View style={s.loanCell}>
                <Text style={s.loanCellLabel}>Paid</Text>
                <Text style={[s.loanCellValue, { color: Colors.success }]}>{formatCurrency(summary.amountPaid)}</Text>
              </View>
              <View style={s.loanCell}>
                <Text style={s.loanCellLabel}>Remaining</Text>
                <Text style={[s.loanCellValue, { color: summary.isFullyPaid ? Colors.success : Colors.warning }]}>
                  {formatCurrency(summary.remainingAmount)}
                </Text>
              </View>
            </View>
          )}

          {summary.hasLoan && (
            <View style={s.progressSection}>
              <View style={s.progressInfo}>
                <Text style={s.progressLabel}>
                  {summary.installmentsPaid} of {summary.totalInstallments} installments
                </Text>
                <Text style={s.progressPercent}>
                  {Math.round((summary.amountPaid / summary.totalPayable) * 100)}%
                </Text>
              </View>
              <View style={s.progressBarLarge}>
                <View style={[s.progressFillLarge, { width: `${Math.min(100, (summary.amountPaid / summary.totalPayable) * 100)}%` }]} />
              </View>
              {perInstallment > 0 && (
                <Text style={s.perInstallment}>
                  {formatCurrency(perInstallment)} per installment
                </Text>
              )}
            </View>
          )}
        </View>

        <View style={s.actions}>
          {summary.hasLoan && !summary.isFullyPaid && (
            <Pressable
              style={({ pressed }) => [s.actionPrimary, pressed && { opacity: 0.8, transform: [{ scale: 0.98 }] }]}
              onPress={() => {
                router.push({ pathname: '/payment/[customerId]', params: { customerId: customer.id } });
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
              }}
            >
              <Feather name="arrow-down-circle" size={20} color={Colors.white} />
              <Text style={s.actionPrimaryText}>Record Payment</Text>
            </Pressable>
          )}

          {summary.hasLoan && summary.isFullyPaid && (
            <Pressable
              style={({ pressed }) => [s.actionSecondary, pressed && { opacity: 0.8 }]}
              onPress={() => {
                router.push({
                  pathname: '/loan/renew',
                  params: { customerId: customer.id, customerName: customer.name, previousLoanEventId: summary.activeLoanEventId ?? '' },
                });
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
              }}
            >
              <Feather name="refresh-cw" size={18} color={Colors.primary} />
              <Text style={s.actionSecondaryText}>Renew Loan</Text>
            </Pressable>
          )}
        </View>

        {customerEvents.length > 0 && (
          <View style={s.historySection}>
            <Text style={s.historySectionTitle}>Payment History</Text>
            {customerEvents.map(event => {
              const color = getEventColor(event.eventType);
              let amountStr = '';
              if (event.eventType === 'INSTALLMENT_PAYMENT') {
                const p = event.payload as InstallmentPaymentPayload;
                const parts: string[] = [];
                if (p.offlineAmount > 0) parts.push(`Cash ${formatCurrency(p.offlineAmount)}`);
                if (p.onlineAmount > 0) parts.push(`Online ${formatCurrency(p.onlineAmount)}`);
                amountStr = parts.join(' + ');
              }

              return (
                <View key={event.eventId} style={s.historyItem}>
                  <View style={[s.historyDot, { backgroundColor: color }]} />
                  <View style={s.historyContent}>
                    <View style={s.historyTopRow}>
                      <Text style={[s.historyLabel, { color }]}>{getEventLabel(event.eventType)}</Text>
                      <Text style={s.historyTime}>{formatDateTime(event.createdAt)}</Text>
                    </View>
                    {amountStr ? <Text style={s.historyAmount}>{amountStr}</Text> : null}
                  </View>
                </View>
              );
            })}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingVertical: 12,
  },
  headerTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 17, color: Colors.text },
  profileCard: {
    marginHorizontal: 20, marginTop: 8, backgroundColor: Colors.white, borderRadius: 16,
    padding: 20,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8,
    elevation: 3,
  },
  profileTop: { flexDirection: 'row', alignItems: 'center', gap: 16, marginBottom: 16 },
  serialLarge: {
    width: 52, height: 52, borderRadius: 14, backgroundColor: Colors.primaryLight,
    alignItems: 'center', justifyContent: 'center',
  },
  serialLargeText: { fontFamily: 'Inter_700Bold', fontSize: 18, color: Colors.primary },
  profileInfo: { flex: 1 },
  profileName: { fontFamily: 'Inter_700Bold', fontSize: 20, color: Colors.text },
  profileVillage: { fontFamily: 'Inter_400Regular', fontSize: 14, color: Colors.textSecondary, marginTop: 2 },
  profilePhone: { fontFamily: 'Inter_400Regular', fontSize: 13, color: Colors.textMuted, marginTop: 2 },
  loanGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  loanCell: {
    width: '47%' as any, backgroundColor: Colors.background, borderRadius: 10, padding: 12,
  },
  loanCellLabel: { fontFamily: 'Inter_500Medium', fontSize: 11, color: Colors.textSecondary, marginBottom: 4 },
  loanCellValue: { fontFamily: 'Inter_700Bold', fontSize: 16, color: Colors.text },
  progressSection: { marginTop: 16 },
  progressInfo: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  progressLabel: { fontFamily: 'Inter_500Medium', fontSize: 13, color: Colors.textSecondary },
  progressPercent: { fontFamily: 'Inter_700Bold', fontSize: 13, color: Colors.primary },
  progressBarLarge: {
    height: 8, backgroundColor: Colors.border, borderRadius: 4, overflow: 'hidden',
  },
  progressFillLarge: { height: '100%', backgroundColor: Colors.primary, borderRadius: 4 },
  perInstallment: {
    fontFamily: 'Inter_400Regular', fontSize: 12, color: Colors.textMuted, marginTop: 8, textAlign: 'center',
  },
  actions: { paddingHorizontal: 20, gap: 10, marginTop: 16 },
  actionPrimary: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
    backgroundColor: Colors.primary, borderRadius: 14, paddingVertical: 16,
  },
  actionPrimaryText: { fontFamily: 'Inter_600SemiBold', fontSize: 16, color: Colors.white },
  actionSecondary: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    backgroundColor: Colors.primaryLight, borderRadius: 14, paddingVertical: 14,
  },
  actionSecondaryText: { fontFamily: 'Inter_600SemiBold', fontSize: 15, color: Colors.primary },
  historySection: { marginHorizontal: 20, marginTop: 24 },
  historySectionTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 16, color: Colors.text, marginBottom: 12 },
  historyItem: { flexDirection: 'row', gap: 12, marginBottom: 16 },
  historyDot: { width: 8, height: 8, borderRadius: 4, marginTop: 6 },
  historyContent: { flex: 1 },
  historyTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  historyLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  historyTime: { fontFamily: 'Inter_400Regular', fontSize: 11, color: Colors.textMuted },
  historyAmount: { fontFamily: 'Inter_500Medium', fontSize: 14, color: Colors.text, marginTop: 4 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  emptyText: { fontFamily: 'Inter_400Regular', fontSize: 15, color: Colors.textSecondary },
});
