import React, { useState } from 'react';
import {
  StyleSheet, Text, View, TextInput, Pressable, Platform, KeyboardAvoidingView, ScrollView, Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { useApp } from '@/lib/context';

export default function CreateCustomerScreen() {
  const { villageId: preselectedVillage } = useLocalSearchParams<{ villageId?: string }>();
  const insets = useSafeAreaInsets();
  const { villages, createCustomer, createNewLoan, selectedArea } = useApp();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [selectedVillage, setSelectedVillage] = useState<string | null>(preselectedVillage ?? null);
  const [loanAmount, setLoanAmount] = useState('');
  const [totalPayable, setTotalPayable] = useState('');
  const [totalInstallments, setTotalInstallments] = useState('');
  const [isOldCustomer, setIsOldCustomer] = useState(false);
  const [paidInstallments, setPaidInstallments] = useState('');
  const [paidAmount, setPaidAmount] = useState('');
  const [saving, setSaving] = useState(false);
  const topInset = Platform.OS === 'web' ? 67 : insets.top;

  const selectedVillageData = villages.find(v => v.id === selectedVillage);

  const canSave = name.trim() && selectedVillage && loanAmount && totalPayable && totalInstallments;

  const handleSave = async () => {
    if (!canSave || saving || !selectedVillageData) return;

    const la = parseFloat(loanAmount);
    const tp = parseFloat(totalPayable);
    const ti = parseInt(totalInstallments);

    if (isNaN(la) || isNaN(tp) || isNaN(ti) || la <= 0 || tp <= 0 || ti <= 0) {
      Alert.alert('Invalid Input', 'Please enter valid loan details');
      return;
    }

    if (tp < la) {
      Alert.alert('Invalid Input', 'Total payable must be greater than or equal to loan amount');
      return;
    }

    setSaving(true);
    try {
      const customer = await createCustomer({
        villageId: selectedVillage,
        villageName: selectedVillageData.name,
        name: name.trim(),
        phone: phone.trim(),
      });

      await createNewLoan(
        customer.id,
        customer.name,
        la,
        tp,
        ti,
        isOldCustomer ? parseInt(paidInstallments) || 0 : undefined,
        isOldCustomer ? parseFloat(paidAmount) || 0 : undefined,
      );

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.back();
    } catch {
      setSaving(false);
    }
  };

  if (villages.length === 0) {
    return (
      <View style={[s.container, { paddingTop: topInset }]}>
        <View style={s.header}>
          <Pressable onPress={() => router.back()} style={({ pressed }) => [s.closeBtn, pressed && { opacity: 0.5 }]}>
            <Feather name="x" size={22} color={Colors.text} />
          </Pressable>
          <Text style={s.headerTitle}>New Customer</Text>
          <View style={{ width: 40 }} />
        </View>
        <View style={s.emptyState}>
          <Feather name="home" size={40} color={Colors.textMuted} />
          <Text style={s.emptyTitle}>No villages yet</Text>
          <Text style={s.emptyText}>Create a village first from Settings</Text>
          <Pressable
            style={({ pressed }) => [s.createVillageBtn, pressed && { opacity: 0.8 }]}
            onPress={() => { router.back(); setTimeout(() => router.push('/village/create'), 300); }}
          >
            <Text style={s.createVillageBtnText}>Create Village</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View style={[s.container, { paddingTop: topInset }]}>
      <View style={s.header}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [s.closeBtn, pressed && { opacity: 0.5 }]}>
          <Feather name="x" size={22} color={Colors.text} />
        </Pressable>
        <Text style={s.headerTitle}>New Customer</Text>
        <Pressable
          onPress={handleSave}
          disabled={!canSave || saving}
          style={({ pressed }) => [s.saveBtn, pressed && { opacity: 0.7 }, (!canSave || saving) && { opacity: 0.4 }]}
        >
          <Feather name="check" size={22} color={Colors.primary} />
        </Pressable>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView contentContainerStyle={s.form} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <Text style={s.sectionLabel}>Customer Details</Text>

          <Text style={s.label}>Village</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.villageRow}>
            {villages.map(v => (
              <Pressable
                key={v.id}
                style={[s.villageChip, selectedVillage === v.id && s.villageActive]}
                onPress={() => { setSelectedVillage(v.id); Haptics.selectionAsync(); }}
              >
                <Text style={[s.villageText, selectedVillage === v.id && s.villageTextActive]}>
                  {v.name}
                </Text>
              </Pressable>
            ))}
          </ScrollView>

          <Text style={s.label}>Name</Text>
          <TextInput
            style={s.input}
            placeholder="Customer name"
            placeholderTextColor={Colors.textMuted}
            value={name}
            onChangeText={setName}
          />

          <Text style={s.label}>Phone</Text>
          <TextInput
            style={s.input}
            placeholder="Phone number (optional)"
            placeholderTextColor={Colors.textMuted}
            value={phone}
            onChangeText={setPhone}
            keyboardType="phone-pad"
          />

          <View style={s.divider} />
          <Text style={s.sectionLabel}>Loan Details</Text>

          <Text style={s.label}>Loan Amount (Given)</Text>
          <TextInput
            style={s.input}
            placeholder="Amount given to customer"
            placeholderTextColor={Colors.textMuted}
            value={loanAmount}
            onChangeText={setLoanAmount}
            keyboardType="numeric"
          />

          <Text style={s.label}>Total Payable Amount</Text>
          <TextInput
            style={s.input}
            placeholder="Total amount to be repaid"
            placeholderTextColor={Colors.textMuted}
            value={totalPayable}
            onChangeText={setTotalPayable}
            keyboardType="numeric"
          />

          <Text style={s.label}>Total Installments</Text>
          <TextInput
            style={s.input}
            placeholder="Number of installments"
            placeholderTextColor={Colors.textMuted}
            value={totalInstallments}
            onChangeText={setTotalInstallments}
            keyboardType="numeric"
          />

          <View style={s.divider} />

          <Pressable
            style={[s.toggleRow]}
            onPress={() => { setIsOldCustomer(!isOldCustomer); Haptics.selectionAsync(); }}
          >
            <View style={[s.checkbox, isOldCustomer && s.checkboxActive]}>
              {isOldCustomer && <Feather name="check" size={14} color={Colors.white} />}
            </View>
            <Text style={s.toggleText}>Onboarding existing customer (has prior payments)</Text>
          </Pressable>

          {isOldCustomer && (
            <>
              <Text style={s.label}>Installments Already Paid</Text>
              <TextInput
                style={s.input}
                placeholder="Number of installments paid"
                placeholderTextColor={Colors.textMuted}
                value={paidInstallments}
                onChangeText={setPaidInstallments}
                keyboardType="numeric"
              />

              <Text style={s.label}>Amount Already Paid</Text>
              <TextInput
                style={s.input}
                placeholder="Total amount already paid"
                placeholderTextColor={Colors.textMuted}
                value={paidAmount}
                onChangeText={setPaidAmount}
                keyboardType="numeric"
              />
            </>
          )}

          <View style={{ height: 40 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  closeBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 17, color: Colors.text },
  saveBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  form: { padding: 20 },
  sectionLabel: { fontFamily: 'Inter_700Bold', fontSize: 16, color: Colors.text, marginBottom: 4 },
  label: { fontFamily: 'Inter_600SemiBold', fontSize: 14, color: Colors.text, marginBottom: 8, marginTop: 16 },
  input: {
    backgroundColor: Colors.white, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 14,
    fontFamily: 'Inter_400Regular', fontSize: 16, color: Colors.text,
    borderWidth: 1, borderColor: Colors.border,
  },
  villageRow: { gap: 8 },
  villageChip: {
    paddingHorizontal: 16, paddingVertical: 10, borderRadius: 10,
    backgroundColor: Colors.white, borderWidth: 1, borderColor: Colors.border,
  },
  villageActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  villageText: { fontFamily: 'Inter_500Medium', fontSize: 14, color: Colors.textSecondary },
  villageTextActive: { color: Colors.white },
  divider: { height: 1, backgroundColor: Colors.border, marginVertical: 24 },
  toggleRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 8 },
  checkbox: {
    width: 22, height: 22, borderRadius: 6, borderWidth: 2, borderColor: Colors.border,
    alignItems: 'center', justifyContent: 'center',
  },
  checkboxActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  toggleText: { fontFamily: 'Inter_400Regular', fontSize: 14, color: Colors.text, flex: 1 },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 40, gap: 12 },
  emptyTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 17, color: Colors.text },
  emptyText: { fontFamily: 'Inter_400Regular', fontSize: 14, color: Colors.textSecondary, textAlign: 'center' },
  createVillageBtn: {
    backgroundColor: Colors.primary, paddingHorizontal: 20, paddingVertical: 12, borderRadius: 10, marginTop: 8,
  },
  createVillageBtnText: { fontFamily: 'Inter_600SemiBold', fontSize: 14, color: Colors.white },
});
