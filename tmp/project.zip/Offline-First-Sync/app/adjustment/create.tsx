import React, { useState } from 'react';
import {
  StyleSheet, Text, View, TextInput, Pressable, Platform, KeyboardAvoidingView, ScrollView, Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { useApp } from '@/lib/context';
import { formatDateTime, getEventLabel, formatCurrency } from '@/lib/calculations';
import type { FinanceEvent } from '@/lib/types';

export default function CreateAdjustmentScreen() {
  const insets = useSafeAreaInsets();
  const { events, createAdjustment } = useApp();
  const [selectedEvent, setSelectedEvent] = useState<string | null>(null);
  const [amount, setAmount] = useState('');
  const [isNegative, setIsNegative] = useState(false);
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState(false);
  const topInset = Platform.OS === 'web' ? 67 : insets.top;

  const recentEvents = events.slice(0, 20);
  const canSave = selectedEvent && amount && reason.trim();

  const handleSave = async () => {
    if (!canSave || saving) return;
    const a = parseFloat(amount);
    if (isNaN(a) || a <= 0) {
      Alert.alert('Invalid Amount', 'Please enter a valid amount');
      return;
    }
    setSaving(true);
    try {
      await createAdjustment(selectedEvent, isNegative ? -a : a, reason.trim());
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.back();
    } catch {
      setSaving(false);
    }
  };

  return (
    <View style={[s.container, { paddingTop: topInset }]}>
      <View style={s.header}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [s.closeBtn, pressed && { opacity: 0.5 }]}>
          <Feather name="x" size={22} color={Colors.text} />
        </Pressable>
        <Text style={s.headerTitle}>Adjustment</Text>
        <Pressable
          onPress={handleSave}
          disabled={!canSave || saving}
          style={({ pressed }) => [s.saveBtn, pressed && { opacity: 0.7 }, (!canSave || saving) && { opacity: 0.4 }]}
        >
          <Feather name="check" size={22} color={Colors.primary} />
        </Pressable>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView contentContainerStyle={s.form} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <Text style={s.hint}>
            Select the original event to adjust. The original event will remain unchanged.
          </Text>

          <Text style={s.label}>Reference Event</Text>
          {recentEvents.map(e => (
            <Pressable
              key={e.eventId}
              style={[s.eventOption, selectedEvent === e.eventId && s.eventOptionActive]}
              onPress={() => { setSelectedEvent(e.eventId); Haptics.selectionAsync(); }}
            >
              <View style={s.eventOptionLeft}>
                <Text style={s.eventOptionType}>{getEventLabel(e.eventType)}</Text>
                <Text style={s.eventOptionTime}>{formatDateTime(e.createdAt)}</Text>
              </View>
              {selectedEvent === e.eventId && <Feather name="check" size={16} color={Colors.primary} />}
            </Pressable>
          ))}

          <View style={s.divider} />

          <Text style={s.label}>Adjustment Type</Text>
          <View style={s.typeRow}>
            <Pressable
              style={[s.typeOption, !isNegative && s.typeActive]}
              onPress={() => { setIsNegative(false); Haptics.selectionAsync(); }}
            >
              <Feather name="plus" size={16} color={!isNegative ? Colors.success : Colors.textMuted} />
              <Text style={[s.typeText, !isNegative && { color: Colors.success }]}>Add</Text>
            </Pressable>
            <Pressable
              style={[s.typeOption, isNegative && s.typeActiveNeg]}
              onPress={() => { setIsNegative(true); Haptics.selectionAsync(); }}
            >
              <Feather name="minus" size={16} color={isNegative ? Colors.danger : Colors.textMuted} />
              <Text style={[s.typeText, isNegative && { color: Colors.danger }]}>Deduct</Text>
            </Pressable>
          </View>

          <Text style={s.label}>Amount</Text>
          <TextInput
            style={s.input}
            placeholder="Adjustment amount"
            placeholderTextColor={Colors.textMuted}
            value={amount}
            onChangeText={setAmount}
            keyboardType="numeric"
          />

          <Text style={s.label}>Reason</Text>
          <TextInput
            style={[s.input, { height: 80, textAlignVertical: 'top' }]}
            placeholder="Why is this adjustment needed?"
            placeholderTextColor={Colors.textMuted}
            value={reason}
            onChangeText={setReason}
            multiline
          />

          <View style={{ height: 40 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  closeBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 17, color: Colors.text },
  saveBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  form: { padding: 20 },
  hint: {
    fontFamily: 'Inter_400Regular', fontSize: 13, color: Colors.textSecondary,
    lineHeight: 20, marginBottom: 16,
  },
  label: { fontFamily: 'Inter_600SemiBold', fontSize: 14, color: Colors.text, marginBottom: 8, marginTop: 16 },
  input: {
    backgroundColor: Colors.white, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 14,
    fontFamily: 'Inter_400Regular', fontSize: 16, color: Colors.text,
    borderWidth: 1, borderColor: Colors.border,
  },
  eventOption: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: Colors.white, borderRadius: 10, padding: 12, marginBottom: 6,
    borderWidth: 1, borderColor: Colors.border,
  },
  eventOptionActive: { borderColor: Colors.primary, backgroundColor: Colors.primaryLight },
  eventOptionLeft: { flex: 1 },
  eventOptionType: { fontFamily: 'Inter_600SemiBold', fontSize: 14, color: Colors.text },
  eventOptionTime: { fontFamily: 'Inter_400Regular', fontSize: 12, color: Colors.textMuted, marginTop: 2 },
  divider: { height: 1, backgroundColor: Colors.border, marginVertical: 16 },
  typeRow: { flexDirection: 'row', gap: 12 },
  typeOption: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    backgroundColor: Colors.white, borderRadius: 10, paddingVertical: 12,
    borderWidth: 2, borderColor: Colors.border,
  },
  typeActive: { borderColor: Colors.success, backgroundColor: Colors.successLight },
  typeActiveNeg: { borderColor: Colors.danger, backgroundColor: Colors.dangerLight },
  typeText: { fontFamily: 'Inter_600SemiBold', fontSize: 14, color: Colors.textSecondary },
});
