import React, { useState } from 'react';
import {
  StyleSheet, Text, View, TextInput, Pressable, Platform, KeyboardAvoidingView, ScrollView,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { useApp } from '@/lib/context';

export default function CreateAreaScreen() {
  const insets = useSafeAreaInsets();
  const { createArea, selectArea } = useApp();
  const [name, setName] = useState('');
  const [isOnboarding, setIsOnboarding] = useState(false);
  const [openingBalance, setOpeningBalance] = useState('');
  const [saving, setSaving] = useState(false);
  const topInset = Platform.OS === 'web' ? 67 : insets.top;

  const handleSave = async () => {
    if (!name.trim() || saving) return;
    setSaving(true);
    try {
      const area = await createArea(
        name.trim(),
        isOnboarding,
        isOnboarding ? parseFloat(openingBalance) || 0 : undefined
      );
      await selectArea(area.id);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.back();
    } catch {
      setSaving(false);
    }
  };

  return (
    <View style={[s.container, { paddingTop: topInset }]}>
      <View style={s.header}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [s.closeBtn, pressed && { opacity: 0.5 }]}>
          <Feather name="x" size={22} color={Colors.text} />
        </Pressable>
        <Text style={s.headerTitle}>New Area</Text>
        <Pressable
          onPress={handleSave}
          disabled={!name.trim() || saving}
          style={({ pressed }) => [s.saveBtn, pressed && { opacity: 0.7 }, (!name.trim() || saving) && { opacity: 0.4 }]}
        >
          <Feather name="check" size={22} color={Colors.primary} />
        </Pressable>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView contentContainerStyle={s.form} keyboardShouldPersistTaps="handled">
          <Text style={s.label}>Area Name</Text>
          <TextInput
            style={s.input}
            placeholder="e.g. North District"
            placeholderTextColor={Colors.textMuted}
            value={name}
            onChangeText={setName}
            autoFocus
          />

          <Text style={s.label}>Finance Type</Text>
          <View style={s.typeRow}>
            <Pressable
              style={[s.typeOption, !isOnboarding && s.typeActive]}
              onPress={() => { setIsOnboarding(false); Haptics.selectionAsync(); }}
            >
              <Feather name="star" size={18} color={!isOnboarding ? Colors.primary : Colors.textMuted} />
              <Text style={[s.typeText, !isOnboarding && s.typeTextActive]}>Fresh Finance</Text>
              <Text style={s.typeDesc}>Starting new</Text>
            </Pressable>
            <Pressable
              style={[s.typeOption, isOnboarding && s.typeActive]}
              onPress={() => { setIsOnboarding(true); Haptics.selectionAsync(); }}
            >
              <Feather name="upload" size={18} color={isOnboarding ? Colors.primary : Colors.textMuted} />
              <Text style={[s.typeText, isOnboarding && s.typeTextActive]}>Existing Finance</Text>
              <Text style={s.typeDesc}>Onboarding</Text>
            </Pressable>
          </View>

          {isOnboarding && (
            <>
              <Text style={s.label}>Opening Balance (BF)</Text>
              <TextInput
                style={s.input}
                placeholder="Enter current cash balance"
                placeholderTextColor={Colors.textMuted}
                value={openingBalance}
                onChangeText={setOpeningBalance}
                keyboardType="numeric"
              />
              <Text style={s.hint}>
                This is the cash you currently have in hand. Past history will not be recalculated.
              </Text>
            </>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  closeBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 17, color: Colors.text },
  saveBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  form: { padding: 20 },
  label: { fontFamily: 'Inter_600SemiBold', fontSize: 14, color: Colors.text, marginBottom: 8, marginTop: 20 },
  input: {
    backgroundColor: Colors.white, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 14,
    fontFamily: 'Inter_400Regular', fontSize: 16, color: Colors.text,
    borderWidth: 1, borderColor: Colors.border,
  },
  typeRow: { flexDirection: 'row', gap: 12 },
  typeOption: {
    flex: 1, backgroundColor: Colors.white, borderRadius: 12, padding: 16,
    alignItems: 'center', gap: 8, borderWidth: 2, borderColor: Colors.border,
  },
  typeActive: { borderColor: Colors.primary, backgroundColor: Colors.primaryLight },
  typeText: { fontFamily: 'Inter_600SemiBold', fontSize: 14, color: Colors.textSecondary },
  typeTextActive: { color: Colors.primary },
  typeDesc: { fontFamily: 'Inter_400Regular', fontSize: 12, color: Colors.textMuted },
  hint: {
    fontFamily: 'Inter_400Regular', fontSize: 12, color: Colors.textSecondary,
    marginTop: 8, lineHeight: 18,
  },
});
