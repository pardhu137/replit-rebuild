import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  StyleSheet, Text, View, ScrollView, Pressable, Platform, FlatList,
  TextInput, Alert, RefreshControl,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Feather, MaterialIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { useApp } from '@/lib/context';
import {
  formatCurrency, formatDateTime, getEventLabel, getEventColor,
  getCustomerLoanSummary,
} from '@/lib/calculations';
import type {
  FinanceEvent, CustomerLoanSummary, Village,
  NewLoanPayload, RenewLoanPayload, InstallmentPaymentPayload,
  ExpensePayload, CapitalAddedPayload, AdjustmentPayload,
  OnboardingBalancePayload,
} from '@/lib/types';

type TabKey = 'dashboard' | 'customers' | 'history';

function TabBar({ active, onSelect }: { active: TabKey; onSelect: (t: TabKey) => void }) {
  const tabs: { key: TabKey; label: string }[] = [
    { key: 'dashboard', label: 'Dashboard' },
    { key: 'customers', label: 'Customers' },
    { key: 'history', label: 'History' },
  ];
  return (
    <View style={ts.tabBar}>
      {tabs.map(t => (
        <Pressable
          key={t.key}
          style={[ts.tab, active === t.key && ts.tabActive]}
          onPress={() => { onSelect(t.key); Haptics.selectionAsync(); }}
        >
          <Text style={[ts.tabText, active === t.key && ts.tabTextActive]}>{t.label}</Text>
        </Pressable>
      ))}
    </View>
  );
}

const ts = StyleSheet.create({
  tabBar: {
    flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: Colors.border,
    paddingHorizontal: 20,
  },
  tab: {
    paddingVertical: 12, marginRight: 28, borderBottomWidth: 2, borderBottomColor: 'transparent',
  },
  tabActive: { borderBottomColor: Colors.primary },
  tabText: { fontFamily: 'Inter_500Medium', fontSize: 15, color: Colors.textMuted },
  tabTextActive: { color: Colors.primary, fontFamily: 'Inter_600SemiBold' },
});

// ============ DASHBOARD TAB ============
function DashboardTab({ areaId }: { areaId: string }) {
  const { events, dashboard, refreshData } = useApp();
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = async () => {
    setRefreshing(true);
    await refreshData();
    setRefreshing(false);
  };

  return (
    <ScrollView
      style={{ flex: 1 }}
      contentContainerStyle={ds.content}
      showsVerticalScrollIndicator={false}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.primary} />}
    >
      <View style={ds.card}>
        <DashRow label="Opening Balance (BF)" value={formatCurrency(dashboard.openingBalance)} color={Colors.text} />
        <View style={ds.divider} />
        <DashRow label="Total Given" value={`- ${formatCurrency(dashboard.totalGiven)}`} color={Colors.danger} />
        <DashRow label="VK (Margin)" value={formatCurrency(dashboard.vk)} color="#D97706" />
        <View style={ds.divider} />
        <View style={ds.row}>
          <View style={{ flex: 1 }}>
            <Text style={ds.label}>Total Collected</Text>
            <View style={ds.collectedBreakdown}>
              <View style={ds.breakdownItem}>
                <Feather name="smartphone" size={12} color={Colors.info} />
                <Text style={ds.breakdownText}>{formatCurrency(dashboard.totalCollectedOnline)}</Text>
              </View>
              <View style={ds.breakdownItem}>
                <MaterialIcons name="payments" size={12} color="#D97706" />
                <Text style={ds.breakdownText}>{formatCurrency(dashboard.totalCollectedOffline)}</Text>
              </View>
            </View>
          </View>
          <Text style={[ds.value, { color: Colors.success }]}>+ {formatCurrency(dashboard.totalCollected)}</Text>
        </View>
        <View style={ds.divider} />
        <DashRow label="Expenses" value={`- ${formatCurrency(dashboard.expenses)}`} color={Colors.danger} />
        <DashRow label="Capital Added" value={`+ ${formatCurrency(dashboard.capitalAdded)}`} color="#D97706" />
        {dashboard.adjustments !== 0 && (
          <DashRow
            label="Adjustments"
            value={`${dashboard.adjustments >= 0 ? '+' : ''} ${formatCurrency(dashboard.adjustments)}`}
            color="#8B5CF6"
          />
        )}
        <View style={ds.divider} />
        <View style={[ds.row, ds.closingRow]}>
          <Text style={ds.closingLabel}>Closing Balance</Text>
          <Text style={[ds.closingValue, dashboard.closingBalance < 0 && { color: Colors.danger }]}>
            {formatCurrency(dashboard.closingBalance)}
          </Text>
        </View>
      </View>

      <View style={ds.quickActions}>
        <Pressable
          style={({ pressed }) => [ds.actionBtn, pressed && { opacity: 0.7 }]}
          onPress={() => { router.push('/expense/create'); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
        >
          <Feather name="minus-circle" size={18} color={Colors.danger} />
          <Text style={ds.actionText}>Expense</Text>
        </Pressable>
        <Pressable
          style={({ pressed }) => [ds.actionBtn, pressed && { opacity: 0.7 }]}
          onPress={() => { router.push('/capital/create'); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
        >
          <Feather name="plus-circle" size={18} color={Colors.info} />
          <Text style={ds.actionText}>Capital</Text>
        </Pressable>
        <Pressable
          style={({ pressed }) => [ds.actionBtn, pressed && { opacity: 0.7 }]}
          onPress={() => { router.push('/adjustment/create'); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
        >
          <Feather name="edit-3" size={18} color="#8B5CF6" />
          <Text style={ds.actionText}>Adjust</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

function DashRow({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <View style={ds.row}>
      <Text style={ds.label}>{label}</Text>
      <Text style={[ds.value, { color }]}>{value}</Text>
    </View>
  );
}

const ds = StyleSheet.create({
  content: { padding: 20, paddingBottom: 40 },
  card: {
    backgroundColor: Colors.white, borderRadius: 16, padding: 20,
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4,
    elevation: 2,
  },
  row: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: 10,
  },
  label: { fontFamily: 'Inter_500Medium', fontSize: 15, color: Colors.text },
  value: { fontFamily: 'Inter_700Bold', fontSize: 17 },
  divider: { height: 1, backgroundColor: Colors.border, marginVertical: 2 },
  collectedBreakdown: { flexDirection: 'row', gap: 12, marginTop: 4 },
  breakdownItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  breakdownText: { fontFamily: 'Inter_400Regular', fontSize: 12, color: Colors.textSecondary },
  closingRow: { paddingTop: 12 },
  closingLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 16, color: Colors.text },
  closingValue: { fontFamily: 'Inter_700Bold', fontSize: 22, color: Colors.primary },
  quickActions: {
    flexDirection: 'row', gap: 10, marginTop: 16,
  },
  actionBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    backgroundColor: Colors.white, borderRadius: 12, paddingVertical: 12,
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.04, shadowRadius: 3,
    elevation: 1,
  },
  actionText: { fontFamily: 'Inter_500Medium', fontSize: 13, color: Colors.text },
});

// ============ CUSTOMERS TAB ============
function CustomersTab({ areaId }: { areaId: string }) {
  const { villages, customerSummaries, deleteCustomer } = useApp();
  const [search, setSearch] = useState('');

  const filteredBySearch = useMemo(() => {
    if (!search.trim()) return customerSummaries;
    const q = search.trim().toLowerCase();
    const num = parseInt(q);
    return customerSummaries.filter(cs => {
      if (!isNaN(num) && cs.customer.serialNumber === num) return true;
      return cs.customer.name.toLowerCase().includes(q) ||
        cs.customer.phone.includes(q) ||
        cs.customer.villageName.toLowerCase().includes(q);
    });
  }, [customerSummaries, search]);

  const villageGroups = useMemo(() => {
    const groups: { village: Village; customers: CustomerLoanSummary[] }[] = [];
    for (const v of villages) {
      const custs = filteredBySearch.filter(cs => cs.customer.villageId === v.id);
      groups.push({ village: v, customers: custs });
    }
    const ungrouped = filteredBySearch.filter(cs => !villages.some(v => v.id === cs.customer.villageId));
    if (ungrouped.length > 0) {
      groups.push({ village: { id: '_other', areaId, name: 'Other', nextSerialNumber: 0, createdAt: '' }, customers: ungrouped });
    }
    return groups.filter(g => g.customers.length > 0 || !search.trim());
  }, [villages, filteredBySearch, search, areaId]);

  return (
    <View style={{ flex: 1 }}>
      <View style={cs.searchBox}>
        <Feather name="search" size={16} color={Colors.textMuted} />
        <TextInput
          style={cs.searchInput}
          placeholder="Search by name or serial #"
          placeholderTextColor={Colors.textMuted}
          value={search}
          onChangeText={setSearch}
        />
        {search.length > 0 && (
          <Pressable onPress={() => setSearch('')}>
            <Feather name="x" size={16} color={Colors.textMuted} />
          </Pressable>
        )}
      </View>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={cs.list} showsVerticalScrollIndicator={false}>
        {villageGroups.length === 0 && villages.length === 0 && !search.trim() ? (
          <View style={cs.empty}>
            <Feather name="home" size={40} color={Colors.textMuted} />
            <Text style={cs.emptyTitle}>No villages yet</Text>
            <Text style={cs.emptyText}>Add a village to start adding customers</Text>
          </View>
        ) : filteredBySearch.length === 0 && search.trim() ? (
          <View style={cs.empty}>
            <Feather name="search" size={36} color={Colors.textMuted} />
            <Text style={cs.emptyTitle}>No results</Text>
          </View>
        ) : (
          villageGroups.map(group => (
            <View key={group.village.id} style={cs.villageGroup}>
              <View style={cs.villageHeader}>
                <View style={cs.villageLeft}>
                  <MaterialIcons name="location-on" size={16} color={Colors.primary} />
                  <Text style={cs.villageName}>{group.village.name}</Text>
                </View>
                <View style={cs.villageRight}>
                  <Text style={cs.villageCount}>{group.customers.length}</Text>
                  <Pressable
                    onPress={() => {
                      router.push({ pathname: '/customer/create', params: { villageId: group.village.id } });
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    }}
                    style={({ pressed }) => [cs.addCustBtn, pressed && { opacity: 0.6 }]}
                  >
                    <Feather name="plus-circle" size={22} color={Colors.primary} />
                  </Pressable>
                </View>
              </View>
              {group.customers.map(summary => (
                <CustomerRow key={summary.customer.id} summary={summary} />
              ))}
            </View>
          ))
        )}
        <View style={{ height: 80 }} />
      </ScrollView>

      <Pressable
        style={({ pressed }) => [cs.addVillageBtn, pressed && { opacity: 0.8, transform: [{ scale: 0.95 }] }]}
        onPress={() => { router.push('/village/create'); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); }}
      >
        <Feather name="plus" size={16} color={Colors.white} />
        <Text style={cs.addVillageBtnText}>Village</Text>
      </Pressable>
    </View>
  );
}

function CustomerRow({ summary }: { summary: CustomerLoanSummary }) {
  const { customer, hasLoan, isFullyPaid, remainingAmount, loanAmount, totalPayable, installmentsPaid, totalInstallments, paidToday, loanType } = summary;

  const loanTypeLabel = useMemo(() => {
    if (!hasLoan || !loanType) return '';
    return loanType === 'RENEWED' ? 'Renewed' : 'New';
  }, [hasLoan, loanType]);

  return (
    <Pressable
      style={({ pressed }) => [cs.customerRow, pressed && { opacity: 0.7 }]}
      onPress={() => {
        router.push({ pathname: '/customer/[id]', params: { id: customer.id } });
        Haptics.selectionAsync();
      }}
    >
      <View style={[cs.serialBadge, isFullyPaid ? cs.serialPaid : cs.serialActive]}>
        <Text style={[cs.serialText, isFullyPaid && cs.serialTextPaid]}>#{customer.serialNumber}</Text>
      </View>
      <View style={cs.custInfo}>
        <View style={cs.custTopRow}>
          <View style={{ flex: 1 }}>
            <Text style={cs.custName} numberOfLines={1}>{customer.name}</Text>
            {hasLoan && (
              <Text style={cs.loanType}>
                {loanTypeLabel} {formatCurrency(loanAmount)}
              </Text>
            )}
          </View>
          {hasLoan && !isFullyPaid ? (
            <Text style={cs.remainingAmt}>{formatCurrency(remainingAmount)}</Text>
          ) : hasLoan && isFullyPaid ? (
            <View style={cs.paidBadge}>
              <Feather name="check-circle" size={13} color={Colors.success} />
              <Text style={cs.paidText}>Paid</Text>
            </View>
          ) : (
            <Text style={cs.noLoan}>No loan</Text>
          )}
        </View>
        {hasLoan && (
          <Text style={cs.installments}>{installmentsPaid}/{totalInstallments} installments</Text>
        )}
      </View>
    </Pressable>
  );
}

const cs = StyleSheet.create({
  searchBox: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: Colors.white, marginHorizontal: 20, marginTop: 12, marginBottom: 8,
    borderRadius: 12, paddingHorizontal: 14, height: 44,
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.04, shadowRadius: 3,
    elevation: 1,
  },
  searchInput: {
    flex: 1, fontFamily: 'Inter_400Regular', fontSize: 14, color: Colors.text, height: '100%',
  },
  list: { paddingHorizontal: 20, paddingTop: 4 },
  villageGroup: { marginBottom: 16 },
  villageHeader: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingVertical: 8,
  },
  villageLeft: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  villageName: { fontFamily: 'Inter_600SemiBold', fontSize: 14, color: Colors.text },
  villageRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  villageCount: { fontFamily: 'Inter_500Medium', fontSize: 13, color: Colors.textSecondary },
  addCustBtn: { padding: 2 },
  customerRow: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: Colors.white, borderRadius: 12, padding: 12, marginBottom: 6,
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.03, shadowRadius: 2,
    elevation: 1,
  },
  serialBadge: {
    width: 34, height: 34, borderRadius: 8, alignItems: 'center', justifyContent: 'center',
  },
  serialActive: { backgroundColor: Colors.primaryLight },
  serialPaid: { backgroundColor: Colors.successLight },
  serialText: { fontFamily: 'Inter_700Bold', fontSize: 12, color: Colors.primary },
  serialTextPaid: { color: Colors.success },
  custInfo: { flex: 1 },
  custTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  custName: { fontFamily: 'Inter_600SemiBold', fontSize: 14, color: Colors.text },
  loanType: { fontFamily: 'Inter_400Regular', fontSize: 12, color: Colors.textSecondary, marginTop: 1 },
  remainingAmt: { fontFamily: 'Inter_700Bold', fontSize: 15, color: Colors.danger },
  paidBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: Colors.successLight, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 5,
  },
  paidText: { fontFamily: 'Inter_600SemiBold', fontSize: 11, color: Colors.success },
  noLoan: { fontFamily: 'Inter_400Regular', fontSize: 12, color: Colors.textMuted },
  installments: { fontFamily: 'Inter_400Regular', fontSize: 11, color: Colors.textMuted, marginTop: 4 },
  addVillageBtn: {
    position: 'absolute', bottom: Platform.OS === 'web' ? 34 : 20, right: 20,
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: Colors.primary, paddingHorizontal: 20, paddingVertical: 12,
    borderRadius: 24,
    shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.15, shadowRadius: 6,
    elevation: 6,
  },
  addVillageBtnText: { fontFamily: 'Inter_600SemiBold', fontSize: 14, color: Colors.white },
  empty: { alignItems: 'center', paddingTop: 60, gap: 10 },
  emptyTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 16, color: Colors.text },
  emptyText: { fontFamily: 'Inter_400Regular', fontSize: 13, color: Colors.textSecondary, textAlign: 'center' },
});

// ============ HISTORY TAB ============
const EVENT_FILTERS = [
  { key: 'ALL', label: 'All' },
  { key: 'NEW_LOAN', label: 'New Loan', color: '#2563EB' },
  { key: 'RENEW_LOAN', label: 'Renewed Loan', color: '#8B5CF6' },
  { key: 'INSTALLMENT_PAYMENT', label: 'Payment', color: '#16A34A' },
  { key: 'EXPENSE', label: 'Expense', color: '#DC2626' },
  { key: 'CAPITAL_ADDED', label: 'Capital', color: '#0EA5E9' },
];

function HistoryTab({ areaId }: { areaId: string }) {
  const { events } = useApp();
  const [filter, setFilter] = useState('ALL');

  const filtered = useMemo(() => {
    if (filter === 'ALL') return events;
    return events.filter(e => e.eventType === filter);
  }, [events, filter]);

  return (
    <View style={{ flex: 1 }}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={hs.filtersRow}
        style={hs.filtersScroll}
      >
        {EVENT_FILTERS.map(f => (
          <Pressable
            key={f.key}
            style={[hs.filterChip, filter === f.key && hs.filterActive]}
            onPress={() => { setFilter(f.key); Haptics.selectionAsync(); }}
          >
            {f.color && (
              <View style={[hs.filterDot, { backgroundColor: f.color }]} />
            )}
            <Text style={[hs.filterText, filter === f.key && hs.filterTextActive]}>
              {f.label}
            </Text>
          </Pressable>
        ))}
      </ScrollView>

      <FlatList
        data={filtered}
        keyExtractor={item => item.eventId}
        renderItem={({ item }) => <HistoryEventItem event={item} />}
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40 }}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={hs.empty}>
            <Feather name="clock" size={40} color={Colors.textMuted} />
            <Text style={hs.emptyTitle}>No events yet</Text>
            <Text style={hs.emptyText}>Financial actions will appear here</Text>
          </View>
        }
      />
    </View>
  );
}

function HistoryEventItem({ event }: { event: FinanceEvent }) {
  const color = getEventColor(event.eventType);

  const getDetails = (): { name: string; info: string } => {
    switch (event.eventType) {
      case 'ONBOARDING_BALANCE': {
        const p = event.payload as OnboardingBalancePayload;
        return { name: '', info: formatCurrency(p.amount) };
      }
      case 'NEW_LOAN': {
        const p = event.payload as NewLoanPayload;
        return { name: p.customerName, info: `Given: ${formatCurrency(p.loanAmount)} | Payable: ${formatCurrency(p.totalPayable)}` };
      }
      case 'RENEW_LOAN': {
        const p = event.payload as RenewLoanPayload;
        return { name: p.customerName, info: `Given: ${formatCurrency(p.loanAmount)} | Payable: ${formatCurrency(p.totalPayable)}` };
      }
      case 'INSTALLMENT_PAYMENT': {
        const p = event.payload as InstallmentPaymentPayload;
        return { name: p.customerName, info: formatCurrency(p.totalAmount) };
      }
      case 'EXPENSE': {
        const p = event.payload as ExpensePayload;
        return { name: p.description, info: formatCurrency(p.amount) };
      }
      case 'CAPITAL_ADDED': {
        const p = event.payload as CapitalAddedPayload;
        return { name: p.description, info: formatCurrency(p.amount) };
      }
      case 'ADJUSTMENT_EVENT': {
        const p = event.payload as AdjustmentPayload;
        return { name: p.reason, info: formatCurrency(Math.abs(p.amount)) };
      }
      default: return { name: '', info: '' };
    }
  };

  const details = getDetails();

  return (
    <View style={hs.eventCard}>
      <View style={[hs.eventDot, { backgroundColor: color }]} />
      <View style={hs.eventContent}>
        <View style={hs.eventTopRow}>
          <Text style={[hs.eventType, { color }]}>{getEventLabel(event.eventType).toUpperCase()}</Text>
          <Text style={hs.eventTime}>{formatDateTime(event.createdAt)}</Text>
        </View>
        {details.name ? <Text style={hs.eventName}>{details.name}</Text> : null}
        <Text style={hs.eventInfo}>{details.info}</Text>
      </View>
    </View>
  );
}

const hs = StyleSheet.create({
  filtersScroll: { flexGrow: 0 },
  filtersRow: { paddingHorizontal: 20, paddingVertical: 12, gap: 8 },
  filterChip: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20,
    backgroundColor: Colors.white, borderWidth: 1, borderColor: Colors.border,
  },
  filterActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  filterDot: { width: 8, height: 8, borderRadius: 4 },
  filterText: { fontFamily: 'Inter_500Medium', fontSize: 13, color: Colors.textSecondary },
  filterTextActive: { color: Colors.white },
  eventCard: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 12,
    backgroundColor: Colors.white, borderRadius: 12, padding: 14, marginBottom: 8,
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.03, shadowRadius: 2,
    elevation: 1,
  },
  eventDot: { width: 10, height: 10, borderRadius: 5, marginTop: 4 },
  eventContent: { flex: 1 },
  eventTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  eventType: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  eventTime: { fontFamily: 'Inter_400Regular', fontSize: 11, color: Colors.textMuted },
  eventName: { fontFamily: 'Inter_500Medium', fontSize: 14, color: Colors.text, marginTop: 4 },
  eventInfo: { fontFamily: 'Inter_600SemiBold', fontSize: 15, color: Colors.text, marginTop: 2 },
  empty: { alignItems: 'center', paddingTop: 60, gap: 10 },
  emptyTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 16, color: Colors.text },
  emptyText: { fontFamily: 'Inter_400Regular', fontSize: 13, color: Colors.textSecondary, textAlign: 'center' },
});

// ============ MAIN AREA SCREEN ============
export default function AreaScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const { areas, selectArea, selectedAreaId } = useApp();
  const [activeTab, setActiveTab] = useState<TabKey>('dashboard');
  const topInset = Platform.OS === 'web' ? 67 : insets.top;

  const area = areas.find(a => a.id === id);

  useEffect(() => {
    if (id && id !== selectedAreaId) {
      selectArea(id);
    }
  }, [id, selectedAreaId, selectArea]);

  if (!area) {
    return (
      <View style={[ms.container, { paddingTop: topInset }]}>
        <View style={ms.header}>
          <Pressable onPress={() => router.back()}>
            <Feather name="arrow-left" size={22} color={Colors.text} />
          </Pressable>
          <Text style={ms.areaTitle}>Area</Text>
          <View style={{ width: 40 }} />
        </View>
        <View style={ms.empty}>
          <Text style={ms.emptyText}>Area not found</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={[ms.container, { paddingTop: topInset }]}>
      <View style={ms.header}>
        <Pressable
          onPress={() => router.back()}
          style={({ pressed }) => [pressed && { opacity: 0.5 }]}
        >
          <Feather name="arrow-left" size={22} color={Colors.text} />
        </Pressable>
        <Text style={ms.areaTitle}>{area.name}</Text>
        <View style={{ width: 40 }} />
      </View>

      <TabBar active={activeTab} onSelect={setActiveTab} />

      {activeTab === 'dashboard' && <DashboardTab areaId={id} />}
      {activeTab === 'customers' && <CustomersTab areaId={id} />}
      {activeTab === 'history' && <HistoryTab areaId={id} />}
    </View>
  );
}

const ms = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingVertical: 12,
  },
  areaTitle: { fontFamily: 'Inter_700Bold', fontSize: 20, color: Colors.text },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  emptyText: { fontFamily: 'Inter_400Regular', fontSize: 15, color: Colors.textSecondary },
});
