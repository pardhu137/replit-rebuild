import React, { useState } from 'react';
import {
  StyleSheet, Text, View, TextInput, Pressable, Platform, KeyboardAvoidingView, ScrollView, Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { useApp } from '@/lib/context';

export default function RenewLoanScreen() {
  const { customerId, customerName, previousLoanEventId } = useLocalSearchParams<{
    customerId: string; customerName: string; previousLoanEventId: string;
  }>();
  const insets = useSafeAreaInsets();
  const { renewLoan } = useApp();
  const [loanAmount, setLoanAmount] = useState('');
  const [totalPayable, setTotalPayable] = useState('');
  const [totalInstallments, setTotalInstallments] = useState('');
  const [saving, setSaving] = useState(false);
  const topInset = Platform.OS === 'web' ? 67 : insets.top;

  const canSave = loanAmount && totalPayable && totalInstallments;

  const handleSave = async () => {
    if (!canSave || saving) return;
    const la = parseFloat(loanAmount);
    const tp = parseFloat(totalPayable);
    const ti = parseInt(totalInstallments);

    if (isNaN(la) || isNaN(tp) || isNaN(ti) || la <= 0 || tp <= 0 || ti <= 0) {
      Alert.alert('Invalid Input', 'Please enter valid loan details');
      return;
    }

    setSaving(true);
    try {
      await renewLoan(customerId, customerName, previousLoanEventId, la, tp, ti);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.back();
    } catch {
      setSaving(false);
    }
  };

  return (
    <View style={[s.container, { paddingTop: topInset }]}>
      <View style={s.header}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [s.closeBtn, pressed && { opacity: 0.5 }]}>
          <Feather name="x" size={22} color={Colors.text} />
        </Pressable>
        <Text style={s.headerTitle}>Renew Loan</Text>
        <Pressable
          onPress={handleSave}
          disabled={!canSave || saving}
          style={({ pressed }) => [s.saveBtn, pressed && { opacity: 0.7 }, (!canSave || saving) && { opacity: 0.4 }]}
        >
          <Feather name="check" size={22} color={Colors.primary} />
        </Pressable>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        <ScrollView contentContainerStyle={s.form} keyboardShouldPersistTaps="handled">
          <View style={s.customerBadge}>
            <Feather name="refresh-cw" size={18} color={Colors.primary} />
            <Text style={s.customerName}>{customerName}</Text>
          </View>

          <Text style={s.label}>Loan Amount (Given)</Text>
          <TextInput
            style={s.input}
            placeholder="Amount given to customer"
            placeholderTextColor={Colors.textMuted}
            value={loanAmount}
            onChangeText={setLoanAmount}
            keyboardType="numeric"
            autoFocus
          />

          <Text style={s.label}>Total Payable Amount</Text>
          <TextInput
            style={s.input}
            placeholder="Total amount to be repaid"
            placeholderTextColor={Colors.textMuted}
            value={totalPayable}
            onChangeText={setTotalPayable}
            keyboardType="numeric"
          />

          <Text style={s.label}>Total Installments</Text>
          <TextInput
            style={s.input}
            placeholder="Number of installments"
            placeholderTextColor={Colors.textMuted}
            value={totalInstallments}
            onChangeText={setTotalInstallments}
            keyboardType="numeric"
          />
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  closeBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 17, color: Colors.text },
  saveBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  form: { padding: 20 },
  customerBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: Colors.primaryLight, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 10,
  },
  customerName: { fontFamily: 'Inter_600SemiBold', fontSize: 15, color: Colors.primary },
  label: { fontFamily: 'Inter_600SemiBold', fontSize: 14, color: Colors.text, marginBottom: 8, marginTop: 20 },
  input: {
    backgroundColor: Colors.white, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 14,
    fontFamily: 'Inter_400Regular', fontSize: 16, color: Colors.text,
    borderWidth: 1, borderColor: Colors.border,
  },
});
